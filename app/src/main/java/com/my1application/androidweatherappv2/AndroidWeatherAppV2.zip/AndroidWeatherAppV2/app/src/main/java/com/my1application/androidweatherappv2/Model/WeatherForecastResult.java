package com.my1application.androidweatherappv2.Model;

import java.io.ObjectInputStream;
import java.util.List;

public class WeatherForecastResult {
    //public static ObjectInputStream.GetField list;
    public String cod;
    public double message;
    public int cnt;
    public static List<MyList> list;
    public City city;

}
