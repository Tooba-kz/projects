package com.my1application.androidweatherappv2.Model;

public class City {
    public  int id;
    public String name;
    public Coord coord;
    public String country;
}
