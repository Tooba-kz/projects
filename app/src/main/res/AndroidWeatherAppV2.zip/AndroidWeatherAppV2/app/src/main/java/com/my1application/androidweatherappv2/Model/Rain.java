package com.my1application.androidweatherappv2.Model;

public class Rain {

}
